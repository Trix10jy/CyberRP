<?php 
$config = [
    'auth' => [
        'auth_client_id' => 'your_discord_bot_client_id',
        'auth_client_secret' => 'your_discord_bot_secret',
        'auth_redirect_index' => 'https://youtsite.com/index',
        'auth_redirect_admin' => 'https://yoursite.com/admin'
    ],
    'db' => [
        'db_host' => 'host',
        'db_user' => 'user',
        'db_name' => 'name',
        'db_password' => 'password'

    ]

]
?>
